#pragma once
#include "Monster.h"
class Dragon : public Monster
{

};

